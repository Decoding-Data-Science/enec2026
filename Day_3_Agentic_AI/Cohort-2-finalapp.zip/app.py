from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from typing import Any, List, Optional

import gradio as gr
from pydantic import Field, PrivateAttr
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import ChatMessage, ChatMessageRole

from llama_index.core import Settings, StorageContext, load_index_from_storage
from llama_index.core.embeddings import BaseEmbedding
from llama_index.core.schema import MetadataMode


APP_BUILD = "V3-2026-09-22"
print(f"STARTING A001 RAG BUILD: {APP_BUILD}", flush=True)

APP_DIR = Path(__file__).resolve().parent
VECTOR_STORE_PATH = Path(
    os.getenv("VECTOR_STORE_PATH", str(APP_DIR / "A001_vector_store"))
).expanduser()

EMBEDDING_ENDPOINT = os.getenv(
    "EMBEDDING_ENDPOINT",
    "databricks-qwen3-embedding-0-6b",
)

CHAT_ENDPOINT = os.getenv(
    "CHAT_ENDPOINT",
    "databricks-meta-llama-3-3-70b-instruct",
)

DEFAULT_TOP_K = int(os.getenv("TOP_K", "4"))
TEMPERATURE = float(os.getenv("TEMPERATURE", "0.1"))
MAX_TOKENS = int(os.getenv("MAX_TOKENS", "800"))

REQUIRED_STORE_FILES = [
    "default__vector_store.json",
    "docstore.json",
    "index_store.json",
    "graph_store.json",
]

SYSTEM_PROMPT = """
You are the A001 Enterprise Document Assistant.

Use only the retrieved A001 document context.

Rules:
1. Answer only from the retrieved context.
2. If the answer is not supported, say:
   "I could not find that in the indexed A001 documents."
3. Do not invent procedures, dates, limits, technical values, approvals,
   inspection requirements, or references.
4. If retrieved sources conflict, explicitly state that.
5. Cite supporting context using [Source N].
6. Keep answers clear and concise.
""".strip()


class DatabricksEmbedding(BaseEmbedding):
    endpoint_name: str = Field(description="Databricks embedding endpoint")
    expected_dimensions: Optional[int] = Field(default=None)

    _client: WorkspaceClient = PrivateAttr()

    def __init__(
        self,
        endpoint_name: str,
        expected_dimensions: Optional[int] = None,
        **kwargs: Any,
    ):
        super().__init__(
            model_name=endpoint_name,
            endpoint_name=endpoint_name,
            expected_dimensions=expected_dimensions,
            embed_batch_size=8,
            **kwargs,
        )
        self._client = WorkspaceClient()

    def _embed(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []

        # Intentionally send ONLY endpoint name + input.
        # This matches Databricks' documented embedding SDK example.
        response = self._client.serving_endpoints.query(
            name=self.endpoint_name,
            input=texts,
        )

        if not response.data:
            raise RuntimeError("Embedding endpoint returned no data.")

        ordered = sorted(
            response.data,
            key=lambda x: x.index if x.index is not None else 0,
        )

        vectors = []
        for item in ordered:
            if item.embedding is None:
                raise RuntimeError("Embedding endpoint returned an empty vector.")

            vector = list(item.embedding)

            if (
                self.expected_dimensions is not None
                and len(vector) != self.expected_dimensions
            ):
                raise RuntimeError(
                    f"Embedding dimension mismatch: stored vectors use "
                    f"{self.expected_dimensions}, but the endpoint returned "
                    f"{len(vector)}."
                )

            vectors.append(vector)

        return vectors

    def _get_query_embedding(self, query: str) -> List[float]:
        return self._embed([query])[0]

    async def _aget_query_embedding(self, query: str) -> List[float]:
        return self._get_query_embedding(query)

    def _get_text_embedding(self, text: str) -> List[float]:
        return self._embed([text])[0]

    async def _aget_text_embedding(self, text: str) -> List[float]:
        return self._get_text_embedding(text)

    def _get_text_embeddings(self, texts: List[str]) -> List[List[float]]:
        return self._embed(texts)


_index = None
_index_lock = threading.Lock()


def _find_embedding_dict(obj: Any) -> Optional[dict]:
    if isinstance(obj, dict):
        d = obj.get("embedding_dict")
        if isinstance(d, dict) and d:
            return d

        for value in obj.values():
            found = _find_embedding_dict(value)
            if found:
                return found

    elif isinstance(obj, list):
        for value in obj:
            found = _find_embedding_dict(value)
            if found:
                return found

    return None


def detect_dimension() -> Optional[int]:
    path = VECTOR_STORE_PATH / "default__vector_store.json"

    if not path.exists():
        return None

    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)

        d = _find_embedding_dict(data)
        if not d:
            return None

        vector = next(iter(d.values()), None)
        if isinstance(vector, list):
            return len(vector)

    except Exception:
        pass

    return None


def validate_store() -> tuple[bool, str]:
    if not VECTOR_STORE_PATH.exists():
        return False, (
            f"❌ Store folder not found: `{VECTOR_STORE_PATH}`"
        )

    missing = [
        x for x in REQUIRED_STORE_FILES
        if not (VECTOR_STORE_PATH / x).exists()
    ]

    if missing:
        return False, (
            "❌ Missing files:\n\n" +
            "\n".join(f"- `{x}`" for x in missing)
        )

    dim = detect_dimension()

    return True, (
        f"✅ **A001 vector store found**\n\n"
        f"**APP BUILD:** `{APP_BUILD}`\n\n"
        f"**Path:** `{VECTOR_STORE_PATH}`\n\n"
        f"**Stored vector dimension:** `{dim}`\n\n"
        f"**Embedding:** `{EMBEDDING_ENDPOINT}`\n\n"
        f"**Chat:** `{CHAT_ENDPOINT}`\n\n"
        f"**Gradio:** `{gr.__version__}`"
    )


def get_index():
    global _index

    if _index is not None:
        return _index

    with _index_lock:
        if _index is not None:
            return _index

        valid, msg = validate_store()
        if not valid:
            raise RuntimeError(msg)

        dim = detect_dimension()

        Settings.embed_model = DatabricksEmbedding(
            endpoint_name=EMBEDDING_ENDPOINT,
            expected_dimensions=dim,
        )

        storage_context = StorageContext.from_defaults(
            persist_dir=str(VECTOR_STORE_PATH)
        )

        _index = load_index_from_storage(storage_context)

        return _index


def health_check():
    try:
        get_index()

        stored_dim = detect_dimension()

        vector = Settings.embed_model.get_query_embedding(
            "A001 health check"
        )

        return (
            f"✅ **V3 health check passed**\n\n"
            f"**Stored dimension:** `{stored_dim}`\n\n"
            f"**Query dimension:** `{len(vector)}`\n\n"
            f"**Build:** `{APP_BUILD}`"
        )

    except Exception as exc:
        return (
            f"❌ **V3 health check failed**\n\n"
            f"**{type(exc).__name__}:** `{exc}`\n\n"
            f"**Build:** `{APP_BUILD}`"
        )


def _text(content: Any) -> str:
    if isinstance(content, str):
        return content

    if isinstance(content, list):
        result = []
        for block in content:
            if isinstance(block, dict) and "text" in block:
                result.append(str(block["text"]))
            elif isinstance(block, str):
                result.append(block)
        return " ".join(result).strip()

    return str(content or "")


def source_label(item, i: int) -> str:
    metadata = item.node.metadata or {}

    source = (
        metadata.get("file_name")
        or metadata.get("filename")
        or metadata.get("source")
        or metadata.get("document_name")
        or metadata.get("file_path")
        or "A001 indexed document"
    )

    page = (
        metadata.get("page_label")
        or metadata.get("page_number")
        or metadata.get("page")
    )

    if page is not None:
        return f"[Source {i}: {source}, page {page}]"

    return f"[Source {i}: {source}]"


def retrieve(question: str, history: list, top_k: int):
    index = get_index()

    prior_user_turns = []

    for item in history[-4:]:
        if isinstance(item, dict) and item.get("role") == "user":
            t = _text(item.get("content"))
            if t:
                prior_user_turns.append(t)

    query = "\n".join(prior_user_turns[-1:] + [question])

    retriever = index.as_retriever(
        similarity_top_k=max(1, min(int(top_k), 8))
    )

    nodes = retriever.retrieve(query)

    context_blocks = []
    source_rows = []

    for i, item in enumerate(nodes, start=1):
        label = source_label(item, i)

        body = item.node.get_content(
            metadata_mode=MetadataMode.NONE
        ).strip()

        score = (
            f"{item.score:.3f}"
            if item.score is not None
            else "n/a"
        )

        context_blocks.append(f"{label}\n{body}")
        source_rows.append(f"- {label} — similarity `{score}`")

    return "\n\n---\n\n".join(context_blocks), source_rows


def generate_answer(question: str, context: str, history: list):
    client = WorkspaceClient()

    recent = []
    for item in history[-4:]:
        if isinstance(item, dict):
            role = item.get("role", "")
            content = _text(item.get("content"))
            if content:
                recent.append(f"{role}: {content}")

    prompt = f"""
RECENT CONVERSATION
{chr(10).join(recent) if recent else "(none)"}

A001 RETRIEVED CONTEXT
{context}

QUESTION
{question}

Answer using only the retrieved context.
Use [Source N] citations.
""".strip()

    response = client.serving_endpoints.query(
        name=CHAT_ENDPOINT,
        messages=[
            ChatMessage(
                role=ChatMessageRole.SYSTEM,
                content=SYSTEM_PROMPT,
            ),
            ChatMessage(
                role=ChatMessageRole.USER,
                content=prompt,
            ),
        ],
        temperature=TEMPERATURE,
        max_tokens=MAX_TOKENS,
    )

    if not response.choices:
        raise RuntimeError("Chat model returned no choices.")

    return str(response.choices[0].message.content or "")


def chat(message: str, history: list, top_k: int):
    try:
        question = (message or "").strip()

        if not question:
            return "Please enter a question."

        context, sources = retrieve(
            question,
            history,
            top_k,
        )

        if not context:
            return "I could not find that in the indexed A001 documents."

        answer = generate_answer(
            question,
            context,
            history,
        )

        return (
            f"{answer}\n\n"
            "---\n\n"
            "**Retrieved sources**\n\n"
            + "\n".join(sources)
        )

    except Exception as exc:
        return (
            f"### Application error — {APP_BUILD}\n\n"
            f"**{type(exc).__name__}:** `{exc}`"
        )


with gr.Blocks(
    title="A001 RAG V3",
    fill_height=True,
) as demo:

    with gr.Sidebar(open=True, width=330):

        gr.Markdown(
            f"""
# A001 RAG V3

**Build:** `{APP_BUILD}`

Uses the existing LlamaIndex vector store.
"""
        )

        top_k = gr.Slider(
            1,
            8,
            value=DEFAULT_TOP_K,
            step=1,
            label="Retrieved chunks",
        )

        test_button = gr.Button(
            "V3 TEST EMBEDDING",
            variant="primary",
        )

        status = gr.Markdown()

    chatbot = gr.Chatbot(
        min_height=500,
        layout="panel",
    )

    gr.ChatInterface(
        fn=chat,
        chatbot=chatbot,
        additional_inputs=[top_k],
        save_history=True,
        fill_height=True,
    )

    test_button.click(
        fn=health_check,
        inputs=[],
        outputs=status,
    )

    demo.load(
        fn=lambda: validate_store()[1],
        inputs=[],
        outputs=status,
    )


demo.queue(
    default_concurrency_limit=4,
    max_size=32,
)

if __name__ == "__main__":
    demo.launch(
        show_error=True,
        share=False,
    )
